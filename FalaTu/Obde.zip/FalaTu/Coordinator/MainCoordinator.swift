//
//  MainCoordinator.swift
//  FalaTu
//
//  Created by Giovanni Favorin de Melo on 26/09/23.
//

import Foundation
import UIKit

enum Event {
    
}

class MainCoordinator: Coordinator {
    var navigationController: UINavigationController?
    
    func eventOcurred(with type: Event) {
//        switch type {
//
//        }
    }
    
    func start() {
        
    }
}
