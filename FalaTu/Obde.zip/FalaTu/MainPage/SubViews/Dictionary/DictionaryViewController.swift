//
//  DictionaryViewController.swift
//  FalaTu
//
//  Created by Giovanni Favorin de Melo on 28/09/23.
//

import UIKit

class DictionaryViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
    }

}
